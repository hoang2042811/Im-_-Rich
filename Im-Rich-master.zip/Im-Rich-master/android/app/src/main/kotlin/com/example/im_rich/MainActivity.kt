package com.example.im_rich

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
